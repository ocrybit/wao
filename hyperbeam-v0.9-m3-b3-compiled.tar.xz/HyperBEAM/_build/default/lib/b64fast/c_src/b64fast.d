c_src/b64fast.o: c_src/b64fast.c \
 /root/.asdf/installs/erlang/27.3.4.6/erts-15.2.7.4/include/erl_nif.h \
 /root/.asdf/installs/erlang/27.3.4.6/erts-15.2.7.4/include/erl_drv_nif.h \
 /root/.asdf/installs/erlang/27.3.4.6/erts-15.2.7.4/include/erl_int_sizes_config.h \
 /root/.asdf/installs/erlang/27.3.4.6/erts-15.2.7.4/include/erl_nif_api_funcs.h \
 c_src/naive.h
