import { always, compose } from 'ramda'

import { withErrorHandler } from './middleware/withErrorHandler.js'

export const withHealthcheckRoutes = (app) => {
  // healthcheck handler
  const healthcheckHandler = compose(
    withErrorHandler,
    always(async (req, res) => {
      const { domain: { apis: { healthcheck } } } = req

      await healthcheck()
        .map((hc) => res.send(hc))
        .toPromise()
    })
  )()

  // Register healthcheck at both / and /status endpoints
  app.get('/', healthcheckHandler)
  app.get('/status', healthcheckHandler)

  return app
}
