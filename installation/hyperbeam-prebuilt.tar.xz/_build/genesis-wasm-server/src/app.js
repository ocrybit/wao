/**
 * The dirty component that knows all the details about which
 * effects, and which configuration should be passed where.
 */

import { setGlobalDispatcher, Agent, EnvHttpProxyAgent, fetch } from 'undici'

import { config } from './config.js'
import { logger } from './logger.js'

import { bootstrap } from './domain/index.js'

import { createEffects as createCuEffects } from './effects/main.cu.js'
import { createEffects as createHbEffects } from './effects/main.hb.js'

import { appendFileSync } from 'node:fs'

// Use EnvHttpProxyAgent if proxy env vars are set, otherwise use regular Agent
// EnvHttpProxyAgent respects https_proxy/HTTPS_PROXY and no_proxy for localhost
const proxyUrl = process.env.https_proxy || process.env.HTTPS_PROXY
console.log('[CU STARTUP] HTTPS_PROXY:', proxyUrl ? 'SET' : 'NOT SET')
console.log('[CU STARTUP] UNIT_MODE:', process.env.UNIT_MODE)
console.log('[CU STARTUP] HB_URL:', process.env.HB_URL)
console.log('[CU STARTUP] DB_URL:', process.env.DB_URL)
console.log('[CU STARTUP] CWD:', process.cwd())
try {
  appendFileSync('./cu_debug.log', `[${new Date().toISOString()}] PROXY: ${proxyUrl ? 'SET' : 'NOT SET'}, UNIT_MODE: ${process.env.UNIT_MODE}, HB_URL: ${process.env.HB_URL}, DB_URL: ${process.env.DB_URL}, CWD: ${process.cwd()}\n`)
} catch(e) {
  console.error('Failed to write log:', e.message)
}

// Ensure DB directory exists
import { mkdirSync, existsSync } from 'node:fs'
import { dirname } from 'node:path'
if (process.env.DB_URL) {
  const dbDir = dirname(process.env.DB_URL)
  console.log('[CU STARTUP] Ensuring DB directory exists:', dbDir)
  try {
    if (!existsSync(dbDir)) {
      mkdirSync(dbDir, { recursive: true })
      console.log('[CU STARTUP] Created DB directory:', dbDir)
    }
  } catch(e) {
    console.error('[CU STARTUP] Failed to create DB directory:', e.message)
  }
}

if (proxyUrl) {
  setGlobalDispatcher(new EnvHttpProxyAgent())
} else {
  setGlobalDispatcher(new Agent({
    /** the timeout, in milliseconds, after which a socket without active requests will time out. Monitors time between activity on a connected socket. This value may be overridden by *keep-alive* hints from the server */
    keepAliveTimeout: 30 * 1000, // 30 seconds
    /** the maximum allowed `idleTimeout`, in milliseconds, when overridden by *keep-alive* hints from the server. */
    keepAliveMaxTimeout: 10 * 60 * 1000 // 10 mins
  }))
}

function chooseEffects (ctx) {
  if (['cu', 'ru'].includes(ctx.UNIT_MODE)) {
    return createCuEffects({ ...config, logger, fetch })
  }

  if (ctx.UNIT_MODE === 'hbu') {
    return createHbEffects({ ...config, logger, fetch })
  }

  throw new Error(`Unknown effects for UNIT_MODE: ${ctx.UNIT_MODE}`)
}

export const cu = async ({ config, logger }) => {
  const effects = {
    ...(await chooseEffects({ ...config, logger, fetch })),
    logger
  }

  const application = await bootstrap({ config, effects })

  process.on('uncaughtException', (err) => {
    console.trace('Uncaught Exception:', err)
    process.exit(1)
  })

  process.on('unhandledRejection', (reason, promise) => {
    console.trace('Unhandled Rejection at:', promise, 'reason:', reason)
  })

  return application.start()
}

export const app = cu({ config, logger })
