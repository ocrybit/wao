{application,quantile_estimator,
             [{description,"A quantile estimator written in Erlang"},
              {vsn,"1.0.0+build.28.ref3c4c505"},
              {licenses,["MIT"]},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {env,[]},
              {links,[{"GitHub","https://github.com/odo/quantile_estimator"}]},
              {modules,[quantile,quantile_estimator]}]}.
