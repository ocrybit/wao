{application,elmdb,
             [{description,"LMDB bindings for Erlang via Rust NIF"},
              {vsn,"0.1.0"},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {env,[]},
              {modules,[elmdb]},
              {licenses,["Apache-2.0"]},
              {links,[]}]}.
